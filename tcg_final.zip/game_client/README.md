## HW2 game platform client

### START
- Install dependencies
`pip install -r requirements.txt`

- Run
`python wasabi.pyz`

### PATHS
- The replay files are stored in
`$CONFIG_HOME$/tcg_wasabi/replays`

For most Linux users, this should be `~/.config/tcg_wasabi/replays`
