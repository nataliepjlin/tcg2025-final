// Wakasagihime
// Plays Chinese Dark Chess (Banqi)!

#include "lib/chess.h"
#include "lib/marisa.h"
#include "lib/types.h"
#include "lib/helper.h"
#include "alphabeta/h/alphabeta.h"
#include "tt/h/zobrist.h"

// Girls are preparing...
__attribute__((constructor)) void prepare()
{
    // Prepare the distance table
    for (Square i = SQ_A1; i < SQUARE_NB; i += 1) {
        for (Square j = SQ_A1; j < SQUARE_NB; j += 1) {
            SquareDistance[i][j] = distance<Rank>(i, j) + distance<File>(i, j);
        }
    }

    // Prepare the attack table (regular)
    Direction dirs[4] = { NORTH, SOUTH, EAST, WEST };
    for (Square sq = SQ_A1; is_okay(sq); sq += 1) {
        Board a = 0;
        for (Direction d : dirs) {
            a |= safe_destination(sq, d);
        }
        PseudoAttacks[sq] = a;
    }

    // Prepare magic
    init_magic<Cannon>(cannonTable, cannonMagics);
}

// le fishe
int main()
{
    std::string line;
    auto engine = std::make_unique<AlphaBetaEngine>();
    Move prev_move;
    while (std::getline(std::cin, line)) {
        Position pos(line);
        if(pos.time_left() < -1.0){
            // not my turn
            if(pos.count(Hidden) == SQUARE_NB){
                // opponent is starting first
                engine->init_game();
            }
            else{
                engine->update_unrevealed(pos);
            }
            continue;
        }
        Move best_move = engine->search(pos);
        info << best_move;
        prev_move = best_move;
    }
}
