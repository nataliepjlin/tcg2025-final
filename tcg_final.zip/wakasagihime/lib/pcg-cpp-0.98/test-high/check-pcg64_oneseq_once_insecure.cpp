#define RNG pcg64_oneseq_once_insecure
#define TWO_ARG_INIT 0

#include "pcg-test.cpp"
