#define RNG pcg32_k1024
#define TWO_ARG_INIT 1

#include "pcg-test.cpp"
