## Usage of Wakasagihime AlphaBeta Engine
`make` at `wakasagihime` directory to compile the engine, then run `./wakasagi` to start the engine.
## Usage of precompiled material score
Compile `wakasagihime/alphabeta/cpp/gen_eval.cpp` with `g++ gen_eval.cpp -o gen` and run `./gen` to generate `material_score.bin`.
Place `material_score.bin` in `wakasagihime` directory or any directory where the engine is executed.