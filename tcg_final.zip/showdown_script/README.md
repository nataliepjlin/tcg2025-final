## Local agent comparison script

### USE
This script requires a *referee program* to adjudicate the game.
You can find a precompiled Linux x86 binary in `showdown_script/referee_program/`.

If you need to compile the referee program yourself, you can copy `wakasagihime/` and replace the `wakasagihime.cpp`.

For the parameters, run `showdown_script/showdown.py --help`.